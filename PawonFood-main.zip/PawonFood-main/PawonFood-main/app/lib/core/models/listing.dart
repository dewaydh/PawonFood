import 'package:latlong2/latlong.dart';

import 'enums.dart';
import 'person.dart';
import 'recipe.dart';

class Listing {
  const Listing({
    required this.id,
    required this.provider,
    required this.photo,
    required this.name,
    required this.category,
    required this.portionsLeft,
    required this.price,
    required this.pickupBy,
    required this.pickupPoint,
    required this.position,
    this.originalPrice,
    this.negotiable = true,
    this.aiStatus = AiStatus.approved,
    this.aiConfidence = 0.9,
    this.aiCategory,
    this.status = ListingStatus.available,
    this.cookedAt,
    this.isOwn = false,
    this.localPhotoPath,
    this.description,
    this.bestBefore,
    this.healthTags = const {},
    this.recipe,
    this.fypItem,
    this.deliveryFee,
    this.allowsPickup = true,
    this.packaging = Packaging.dibungkus,
  });

  final String id;
  final Person provider;

  /// Asset path of the photo (mock data) or empty when [localPhotoPath] is used.
  final String photo;

  /// Path of a photo taken by the live camera (listings published in the app).
  final String? localPhotoPath;
  final String name;
  final FoodCategory category;
  final int portionsLeft;
  final int? originalPrice;
  final int price;
  final bool negotiable;
  final DateTime pickupBy;
  final String pickupPoint;
  final LatLng position;
  final AiStatus aiStatus;
  final double aiConfidence;

  /// The AI's category for a listing published in the app; null for mock data or when the AI could not tell.
  final FoodCategory? aiCategory;
  final ListingStatus status;
  final DateTime? cookedAt;
  final bool isOwn;

  /// Short note from the provider (B8 "Deskripsi").
  final String? description;

  /// "Baik digunakan sebelum" for sealed food (C15c).
  final DateTime? bestBefore;

  /// "Pilihan sehat" tags set by the provider (pre-filled by the AI).
  final Set<HealthTag> healthTags;

  /// Recipe idea the provider attached when sharing fresh ingredients.
  final Recipe? recipe;

  /// This listing's item id in the FYP recommender (ml/fyp), e.g. "i106". Demo mapping in the mock data; null for
  /// listings published in the app, which the model has never seen.
  final String? fypItem;

  /// "Bisa diantar": the fee the provider set (Rp0, Rp2.000 or Rp3.000, all of it theirs). Null when the food is pickup only.
  final int? deliveryFee;

  /// "Ambil di tempat": the receiver may come to the pickup point. False for delivery-only food, which then always has a
  /// [deliveryFee].
  final bool allowsPickup;

  /// "Kemasan": already wrapped, or the receiver brings a container. [Packaging.wadahSendiri] never has a [deliveryFee].
  final Packaging packaging;

  bool get bringsContainer => packaging == Packaging.wadahSendiri;
  bool get isFree => price == 0;

  /// The receiver can pick "Minta diantar" (PRD Handover methods).
  bool get canDeliver => deliveryFee != null;

  /// The provider changed the category the AI filled in.
  bool get categoryCorrected => aiCategory != null && aiCategory != category;
  bool get isSoldOut => status == ListingStatus.habis || portionsLeft <= 0;
  bool isExpired(DateTime now) => status == ListingStatus.expired || now.isAfter(pickupBy);

  /// "Sedang hangat": cooked within the last 90 minutes.
  bool isWarm(DateTime now) => category == FoodCategory.makananMatang && cookedAt != null && now.difference(cookedAt!).inMinutes <= 90;

  Listing copyWith({int? portionsLeft, ListingStatus? status}) => Listing(
        id: id,
        provider: provider,
        photo: photo,
        localPhotoPath: localPhotoPath,
        name: name,
        category: category,
        portionsLeft: portionsLeft ?? this.portionsLeft,
        originalPrice: originalPrice,
        price: price,
        negotiable: negotiable,
        pickupBy: pickupBy,
        pickupPoint: pickupPoint,
        position: position,
        aiStatus: aiStatus,
        aiConfidence: aiConfidence,
        aiCategory: aiCategory,
        status: status ?? this.status,
        cookedAt: cookedAt,
        isOwn: isOwn,
        description: description,
        bestBefore: bestBefore,
        healthTags: healthTags,
        recipe: recipe,
        fypItem: fypItem,
        deliveryFee: deliveryFee,
        allowsPickup: allowsPickup,
        packaging: packaging,
      );

  /// Builds a listing from mock JSON. Times are relative to [now] so the data never goes stale.
  factory Listing.fromJson(Map<String, dynamic> j, Person provider, DateTime now, {String? ownerId, Recipe? recipe}) => Listing(
        id: j['id'] as String,
        provider: provider,
        photo: j['photo'] as String,
        name: j['name'] as String,
        category: FoodCategory.fromKey(j['category'] as String),
        portionsLeft: (j['portions'] as num).toInt(),
        originalPrice: (j['originalPrice'] as num?)?.toInt(),
        price: (j['price'] as num).toInt(),
        negotiable: (j['negotiable'] ?? true) as bool,
        pickupBy: now.add(Duration(minutes: (j['pickupInMinutes'] as num).toInt())),
        pickupPoint: (j['pickupPoint'] ?? '') as String,
        position: LatLng((j['lat'] as num).toDouble(), (j['lng'] as num).toDouble()),
        aiConfidence: (j['aiConfidence'] as num?)?.toDouble() ?? 0.9,
        status: (j['soldOut'] ?? false) as bool ? ListingStatus.habis : ListingStatus.available,
        cookedAt: j['cookedMinutesAgo'] == null ? null : now.subtract(Duration(minutes: (j['cookedMinutesAgo'] as num).toInt())),
        isOwn: provider.id == ownerId,
        description: j['description'] as String?,
        bestBefore: j['bestBeforeInDays'] == null ? null : now.add(Duration(days: (j['bestBeforeInDays'] as num).toInt())),
        healthTags: HealthTag.parseList(j['healthTags']),
        recipe: recipe,
        fypItem: j['fypItem'] as String?,
        deliveryFee: (j['deliveryFee'] as num?)?.toInt(),
        allowsPickup: (j['pickup'] ?? true) as bool,
        packaging: Packaging.fromKey(j['packaging']),
      );
}
